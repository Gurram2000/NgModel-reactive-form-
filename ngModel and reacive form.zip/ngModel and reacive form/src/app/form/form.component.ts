import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, NgForm, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.css']
})
export class FormComponent implements OnInit {
 
  enrollform:any;
  public mydata={
    "name":'',
    "email":'',
    "dept":'',
    "sec":''
  }
  
  


  constructor(private fb: FormBuilder, private router: Router) {

    
   

    
  }

  ngOnInit(): void {

    // this.enrollform=new FormGroup({

    //   "name":new FormControl(null,[Validators.required]),
    //   "email":new FormControl(null,[Validators.required]),
    //   "dept":new FormControl(null,[Validators.required]),
    //   "sec":new FormControl(null,[Validators.required])
    

    // })
    this.enrollform=this.fb.group({

      "name":['',Validators.required],
      "email":['',Validators.required],
      "dept":['',Validators.required],
      "sec":['',Validators.required],
    

    })
   
  
  }

  public submitData()  
  {
    // this.listdata.push(this.enrollform.value);
    // localStorage.setItem("studentdata", JSON.stringify(this.listdata));

    console.log(this.mydata);
    


    // this.enrollform.controls['name'].markAsTouched();
    // this.enrollform.controls['email'].markAsTouched();
    // this.enrollform.controls['dept'].markAsTouched();
    // this.enrollform.controls['sec'].markAsTouched();
  }

  get name() {return this.enrollform.get('name')}  
  get email() {return this.enrollform.get('email')} 
  get dept() {return this.enrollform.get('dept')} 
  get sec() {return this.enrollform.get('sec')} 


  }