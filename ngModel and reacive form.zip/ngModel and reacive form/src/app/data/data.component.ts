import { Component, OnInit } from '@angular/core';
import { FormComponent } from '../form/form.component';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {

  constructor() { }

  listdata= Array();
  

  ngOnInit(): void {
    
    this.listdata=JSON.parse(localStorage.getItem('studentdata') || '{}');
    
    

  }
  

}
